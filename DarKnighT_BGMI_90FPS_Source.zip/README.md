# DarKnighT BGMI 90 FPS Analyzer

A native Android starter app for rooted/non-rooted Android tablets.

## What it does
- Detects device model, Android version, SoC properties, RAM and display refresh modes.
- Checks root availability using a read-only `su -c id` command.
- Reports whether the display advertises a 90 Hz-or-higher mode.
- Provides safe, manual BGMI optimization guidance.

## What it deliberately does not do
- Does not modify BGMI configuration or OBB/data files.
- Does not spoof device identity, bypass BGMI device whitelists, or disable anti-cheat.
- Does not claim that a 90 Hz display guarantees 90 FPS.
- Does not force GPU clocks, voltage, thermal limits, or system performance profiles.

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then:
- Build > Build Bundle(s) / APK(s) > Build APK(s)
- Install the generated debug APK on your tablet.

Requirements: JDK 17, Android SDK 35, Android Gradle Plugin 8.7.3, Kotlin 2.0.21.

## Notes
The exact tablet model is discovered at runtime. The app uses Android's reported display modes; actual BGMI frame-rate options are controlled by the game build, device support and thermal conditions.
