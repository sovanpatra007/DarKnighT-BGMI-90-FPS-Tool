package com.darknight.bgmi

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.os.Process
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import android.graphics.Color
import android.content.Context
import android.os.HardwarePropertiesManager
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 24)
    private val panel = Color.rgb(18, 28, 45)
    private val cyan = Color.rgb(0, 213, 255)
    private lateinit var rootStatus: TextView
    private lateinit var report: TextView
    private lateinit var fpsStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        refreshDiagnostics()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
            setBackgroundColor(bg)
        }
        scroll.addView(layout)

        val brand = TextView(this).apply {
            text = "🦇 DarKnighT"
            textSize = 28f; setTextColor(cyan); gravity = Gravity.CENTER
        }
        layout.addView(brand)
        layout.addView(text("BGMI 90 FPS ANALYZER", 16f, Color.WHITE, true, 8))
        layout.addView(text("Device diagnostics • Safe optimization • No game-file patching", 12f, 0xFF9FB0C8.toInt(), false, 18))

        fpsStatus = text("Checking FPS capability…", 21f, Color.WHITE, true, 12)
        card(layout, fpsStatus)

        rootStatus = text("Root access: checking…", 15f, Color.WHITE, true, 8)
        card(layout, rootStatus)

        val scan = Button(this).apply {
            text = "SCAN DEVICE AGAIN"
            setTextColor(Color.BLACK); setBackgroundColor(cyan)
            setOnClickListener { refreshDiagnostics() }
        }
        layout.addView(scan, matchWrap())

        val refresh = Button(this).apply {
            text = "OPEN DISPLAY SETTINGS"
            setOnClickListener {
                try { startActivity(android.content.Intent(android.provider.Settings.ACTION_DISPLAY_SETTINGS)) }
                catch (_: Exception) { Toast.makeText(this@MainActivity, "Display settings unavailable", Toast.LENGTH_SHORT).show() }
            }
        }
        layout.addView(refresh, matchWrap())

        report = text("", 13f, 0xFFD8E2F0.toInt(), false, 12)
        card(layout, report)

        layout.addView(text("SAFE OPTIMIZATION CHECKLIST", 16f, cyan, true, 14))
        layout.addView(text("1. Set the tablet display to its highest supported refresh rate.\n2. In BGMI, select Smooth graphics and the highest FPS option the game itself offers.\n3. Close heavy background apps before launching BGMI.\n4. Keep the device cool; thermal throttling can reduce FPS.\n5. Keep adequate free storage and update BGMI from its official store.", 14f, Color.WHITE, false, 10))
        layout.addView(text("IMPORTANT", 15f, 0xFFFFC66D.toInt(), true, 14))
        layout.addView(text("This app does not edit BGMI files, bypass device whitelists, spoof device identity, or promise 90 FPS. A 90 Hz screen does not mean the game can render 90 FPS. Root is used only for a harmless 'su -c id' access check.", 13f, 0xFFB9C6D8.toInt(), false, 8))
        setContentView(scroll)
    }

    private fun refreshDiagnostics() {
        val root = checkRoot()
        rootStatus.text = if (root) "Root access: GRANTED" else "Root access: NOT AVAILABLE"
        rootStatus.setTextColor(if (root) 0xFF65E6A5.toInt() else 0xFFFF8B8B.toInt())

        val dm = resources.displayMetrics
        val hz = try { windowManager.defaultDisplay.refreshRate } catch (_: Exception) { 0f }
        val maxHz = try {
            if (Build.VERSION.SDK_INT >= 23) {
                windowManager.defaultDisplay.supportedModes.maxOfOrNull { it.refreshRate } ?: hz
            } else hz
        } catch (_: Exception) { hz }

        val totalRam = (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager)
            .let { info -> android.app.ActivityManager.MemoryInfo().also { info.getMemoryInfo(it) }.totalMem / (1024*1024) }
        val availRam = (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager)
            .let { info -> android.app.ActivityManager.MemoryInfo().also { info.getMemoryInfo(it) }.availMem / (1024*1024) }

        val gpu = readProp("ro.hardware.egl") ?: "Not exposed by Android"
        val soc = readProp("ro.soc.model") ?: readProp("ro.hardware") ?: "Unknown"
        val model = "${Build.MANUFACTURER} ${Build.MODEL}"
        val thermal = if (Build.VERSION.SDK_INT >= 29) "Thermal status: ${thermalLabel()}" else "Thermal status: API unavailable"

        fpsStatus.text = when {
            maxHz >= 89f -> "Display supports up to ${maxHz.toInt()} Hz\n90 FPS may be possible; BGMI support still needs verification."
            maxHz >= 59f -> "Display maximum: ${maxHz.toInt()} Hz\n90 FPS is not supported by the current display mode."
            else -> "Display maximum: ${maxHz.toInt()} Hz\nA 90 FPS target is not currently realistic."
        }
        report.text = "DEVICE REPORT\n$model\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nSoC: $soc\nEGL hardware: $gpu\nCurrent refresh rate: ${"%.1f".format(hz)} Hz\nMaximum reported refresh rate: ${"%.1f".format(maxHz)} Hz\nRAM: ${totalRam} MB total / ${availRam} MB available\n$thermal\n\nNote: Android does not expose a reliable universal BGMI FPS-capability API. Confirm the actual in-game FPS options and measure gameplay separately."
    }

    private fun checkRoot(): Boolean {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val output = p.inputStream.bufferedReader().readText()
            p.waitFor() == 0 && output.contains("uid=0")
        } catch (_: Exception) { false }
    }

    private fun readProp(name: String): String? {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("/system/bin/getprop", name))
            val value = p.inputStream.bufferedReader().readText().trim()
            p.waitFor()
            value.takeIf { it.isNotBlank() }
        } catch (_: Exception) { null }
    }

    private fun thermalLabel(): String {
        return try {
            val manager = getSystemService(Context.HARDWARE_PROPERTIES_SERVICE) as HardwarePropertiesManager
            val status = manager.getDeviceTemperatures(HardwarePropertiesManager.DEVICE_TEMPERATURE_SKIN, HardwarePropertiesManager.TEMPERATURE_CURRENT)
            if (status.isEmpty()) "Unavailable" else "${"%.1f".format(status.maxOrNull() ?: 0f)}°C skin sensor"
        } catch (_: Exception) { "Unavailable on this device" }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean, bottom: Int): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(4, 5, 4, bottom)
        }

    private fun card(parent: LinearLayout, view: View) {
        val box = LinearLayout(this).apply {
            setPadding(16, 14, 16, 14); setBackgroundColor(panel)
            addView(view)
        }
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14 }
        parent.addView(box, params)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 }
}
